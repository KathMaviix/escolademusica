package main;

import model.Aluno;

import model.Professor;
import model.Funcionario;
import model.Pessoa;
import identificavel.Identificavel;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Pessoa> pessoas = new ArrayList<>();

        pessoas.add(new Aluno("Alice", 20, "M001"));
        pessoas.add(new Professor("Carlos", 35, "P001"));
        pessoas.add(new Funcionario("Maria", 28, "F001"));

        for (Pessoa pessoa : pessoas) {
            System.out.println("Nome: " + pessoa.nome);
            System.out.println("Idade: " + pessoa.idade);
            System.out.println("Identificador: " + ((Identificavel) pessoa).getId());
            System.out.println("Atividade: " + pessoa.atividade());
            System.out.println();
        }
    }
}
