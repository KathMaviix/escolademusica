package identificavel;
public interface Identificavel {
    String getId();

}
